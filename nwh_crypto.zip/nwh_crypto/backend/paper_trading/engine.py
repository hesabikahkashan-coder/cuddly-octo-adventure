"""
Paper Trading Engine
Simulates real trading using live prices with virtual balance.
Full analytics, risk management integration, and realistic order execution.
"""
import asyncio
import uuid
from datetime import datetime, timezone
from typing import Dict, List, Optional, Any
from dataclasses import dataclass, field
from ..core.logging import get_logger, get_trade_logger
from ..risk_engine.engine import RiskEngine
from ..risk_engine.models import TradeSignal, RiskValidationResult, RiskStatus

logger = get_logger(__name__)
trade_logger = get_trade_logger()


@dataclass
class PaperPosition:
    id: str
    symbol: str
    direction: str  # long/short
    entry_price: float
    quantity: float
    stop_loss: float
    take_profit_1: Optional[float]
    take_profit_2: Optional[float]
    take_profit_3: Optional[float]
    strategy_id: Optional[str]
    opened_at: str
    current_price: float = 0.0
    unrealized_pnl: float = 0.0
    unrealized_pnl_percent: float = 0.0
    partial_tp_hit: int = 0  # 0=none, 1=TP1, 2=TP2
    trailing_stop: Optional[float] = None
    metadata: Dict = field(default_factory=dict)


@dataclass
class PaperTrade:
    id: str
    symbol: str
    direction: str
    entry_price: float
    exit_price: float
    quantity: float
    stop_loss: float
    pnl: float
    pnl_percent: float
    fees: float
    opened_at: str
    closed_at: str
    exit_reason: str  # stop_loss, take_profit_1/2/3, manual, trailing_stop
    strategy_id: Optional[str] = None


class PaperTradingEngine:
    """
    Paper Trading Engine.
    
    Uses REAL live prices but VIRTUAL balance.
    Fully integrated with the Risk Engine.
    Simulates realistic slippage and fees.
    """

    FEE_RATE = 0.001  # 0.1% per trade (Binance standard)
    SLIPPAGE_PERCENT = 0.0005  # 0.05% slippage simulation

    def __init__(
        self,
        initial_balance: float = 10000.0,
        risk_engine: Optional[RiskEngine] = None,
    ):
        self.initial_balance = initial_balance
        self.balance = initial_balance
        self.risk_engine = risk_engine or RiskEngine()

        self._positions: Dict[str, PaperPosition] = {}  # position_id -> position
        self._trade_history: List[PaperTrade] = []
        self._current_prices: Dict[str, float] = {}
        self._lock = asyncio.Lock()

        # Initialize drawdown guard with starting balance
        asyncio.create_task(self._init_risk())

        logger.info(f"Paper trading engine started. Balance: ${initial_balance:,.2f}")

    async def _init_risk(self):
        await self.risk_engine.drawdown_guard.initialize_day("paper_user", self.balance)

    # ============================================================
    # Price Feed
    # ============================================================

    async def update_price(self, symbol: str, price: float):
        """Update current price and check stop/tp conditions."""
        self._current_prices[symbol] = price
        await self._check_positions(symbol, price)

    async def _check_positions(self, symbol: str, current_price: float):
        """Check all open positions for stop loss / take profit triggers."""
        async with self._lock:
            positions_to_close = []

            for pos_id, pos in self._positions.items():
                if pos.symbol != symbol:
                    continue

                pos.current_price = current_price
                pos.unrealized_pnl = self._calc_pnl(pos, current_price)
                pos.unrealized_pnl_percent = (pos.unrealized_pnl / (pos.entry_price * pos.quantity)) * 100

                # Update trailing stop
                if pos.trailing_stop:
                    pos.trailing_stop = self._update_trailing_stop(pos, current_price)

                exit_reason = None

                if pos.direction == "long":
                    # Stop Loss
                    if current_price <= pos.stop_loss:
                        exit_reason = "stop_loss"
                    # Trailing Stop
                    elif pos.trailing_stop and current_price <= pos.trailing_stop:
                        exit_reason = "trailing_stop"
                    # Take Profits
                    elif pos.take_profit_1 and current_price >= pos.take_profit_1 and pos.partial_tp_hit == 0:
                        exit_reason = "take_profit_1"
                    elif pos.take_profit_2 and current_price >= pos.take_profit_2 and pos.partial_tp_hit == 1:
                        exit_reason = "take_profit_2"
                    elif pos.take_profit_3 and current_price >= pos.take_profit_3:
                        exit_reason = "take_profit_3"

                else:  # short
                    if current_price >= pos.stop_loss:
                        exit_reason = "stop_loss"
                    elif pos.trailing_stop and current_price >= pos.trailing_stop:
                        exit_reason = "trailing_stop"
                    elif pos.take_profit_1 and current_price <= pos.take_profit_1 and pos.partial_tp_hit == 0:
                        exit_reason = "take_profit_1"
                    elif pos.take_profit_2 and current_price <= pos.take_profit_2 and pos.partial_tp_hit == 1:
                        exit_reason = "take_profit_2"
                    elif pos.take_profit_3 and current_price <= pos.take_profit_3:
                        exit_reason = "take_profit_3"

                if exit_reason:
                    positions_to_close.append((pos_id, current_price, exit_reason))

            for pos_id, price, reason in positions_to_close:
                await self._close_position(pos_id, price, reason)

    def _update_trailing_stop(self, pos: PaperPosition, current_price: float) -> float:
        """Move trailing stop in favorable direction."""
        if pos.direction == "long":
            trail_distance = pos.entry_price - pos.trailing_stop
            new_stop = current_price - trail_distance
            return max(new_stop, pos.trailing_stop)
        else:
            trail_distance = pos.trailing_stop - pos.entry_price
            new_stop = current_price + trail_distance
            return min(new_stop, pos.trailing_stop)

    # ============================================================
    # Trade Execution
    # ============================================================

    async def open_position(
        self,
        signal: TradeSignal,
        user_id: str = "paper_user"
    ) -> Dict[str, Any]:
        """
        Open a paper trading position.
        Goes through full risk validation first.
        """
        async with self._lock:
            open_count = len(self._positions)

            # Risk validation
            result: RiskValidationResult = await self.risk_engine.validate_trade(
                signal=signal,
                user_id=user_id,
                account_balance=self.balance,
                open_trade_count=open_count,
            )

            if not result.is_approved:
                logger.warning(f"Paper trade rejected: {result.rejection_messages}")
                return {
                    "success": False,
                    "reason": result.rejection_messages,
                    "status": result.status.value
                }

            # Apply slippage simulation
            slippage = signal.entry_price * self.SLIPPAGE_PERCENT
            actual_entry = signal.entry_price + slippage if signal.direction == "long" else signal.entry_price - slippage

            quantity = result.approved_quantity
            cost = actual_entry * quantity
            fee = cost * self.FEE_RATE

            if cost + fee > self.balance:
                return {"success": False, "reason": ["Insufficient paper balance"]}

            self.balance -= fee  # Deduct opening fee

            pos_id = str(uuid.uuid4())
            position = PaperPosition(
                id=pos_id,
                symbol=signal.symbol,
                direction=signal.direction,
                entry_price=actual_entry,
                quantity=quantity,
                stop_loss=result.approved_stop_loss,
                take_profit_1=result.approved_take_profit_1,
                take_profit_2=result.approved_take_profit_2,
                take_profit_3=result.approved_take_profit_3,
                strategy_id=signal.strategy_id,
                opened_at=datetime.now(timezone.utc).isoformat(),
                current_price=actual_entry,
                trailing_stop=signal.entry_price * (1 - signal.trailing_stop_percent / 100)
                    if signal.use_trailing_stop and signal.trailing_stop_percent else None,
            )

            self._positions[pos_id] = position
            await self.risk_engine.register_trade_opened(user_id, pos_id)

            trade_logger.log_trade_opened({
                "mode": "paper",
                "symbol": signal.symbol,
                "direction": signal.direction,
                "entry": actual_entry,
                "quantity": quantity,
                "stop_loss": result.approved_stop_loss,
                "risk_percent": result.risk_percent,
            })

            return {
                "success": True,
                "position_id": pos_id,
                "entry_price": actual_entry,
                "quantity": quantity,
                "stop_loss": result.approved_stop_loss,
                "take_profit_1": result.approved_take_profit_1,
                "fee": fee,
                "balance_after": self.balance,
            }

    async def close_position_manual(self, position_id: str) -> Dict:
        """Manually close a position."""
        async with self._lock:
            if position_id not in self._positions:
                return {"success": False, "reason": "Position not found"}
            pos = self._positions[position_id]
            price = self._current_prices.get(pos.symbol, pos.current_price)
        return await self._close_position(position_id, price, "manual")

    async def _close_position(self, position_id: str, exit_price: float, reason: str) -> Dict:
        """Internal: close position and record trade."""
        if position_id not in self._positions:
            return {}

        pos = self._positions.pop(position_id)
        fee = exit_price * pos.quantity * self.FEE_RATE
        pnl = self._calc_pnl(pos, exit_price) - fee

        # Update balance
        position_value = exit_price * pos.quantity
        if pos.direction == "long":
            self.balance += position_value + pnl
        else:
            self.balance += pnl

        pnl_percent = (pnl / (pos.entry_price * pos.quantity)) * 100

        trade = PaperTrade(
            id=str(uuid.uuid4()),
            symbol=pos.symbol,
            direction=pos.direction,
            entry_price=pos.entry_price,
            exit_price=exit_price,
            quantity=pos.quantity,
            stop_loss=pos.stop_loss,
            pnl=pnl,
            pnl_percent=pnl_percent,
            fees=fee,
            opened_at=pos.opened_at,
            closed_at=datetime.now(timezone.utc).isoformat(),
            exit_reason=reason,
            strategy_id=pos.strategy_id,
        )
        self._trade_history.append(trade)

        await self.risk_engine.register_trade_closed("paper_user", position_id, pnl, self.balance)

        if reason == "stop_loss":
            trade_logger.log_stop_loss_hit({"symbol": pos.symbol, "pnl": pnl, "mode": "paper"})
        elif "take_profit" in reason:
            trade_logger.log_take_profit_hit({"symbol": pos.symbol, "pnl": pnl, "mode": "paper"})

        trade_logger.log_trade_closed({
            "mode": "paper",
            "symbol": pos.symbol,
            "pnl": round(pnl, 4),
            "pnl_percent": round(pnl_percent, 2),
            "reason": reason,
            "balance": round(self.balance, 2),
        })

        return {"success": True, "trade": trade, "pnl": pnl, "balance": self.balance}

    def _calc_pnl(self, pos: PaperPosition, current_price: float) -> float:
        if pos.direction == "long":
            return (current_price - pos.entry_price) * pos.quantity
        else:
            return (pos.entry_price - current_price) * pos.quantity

    # ============================================================
    # Analytics
    # ============================================================

    def get_analytics(self) -> Dict:
        trades = self._trade_history
        if not trades:
            return {"message": "No trades yet"}

        total = len(trades)
        wins = [t for t in trades if t.pnl > 0]
        losses = [t for t in trades if t.pnl <= 0]
        win_rate = len(wins) / total * 100 if total > 0 else 0
        total_pnl = sum(t.pnl for t in trades)
        total_fees = sum(t.fees for t in trades)
        avg_win = sum(t.pnl for t in wins) / len(wins) if wins else 0
        avg_loss = sum(t.pnl for t in losses) / len(losses) if losses else 0
        profit_factor = abs(sum(t.pnl for t in wins) / sum(t.pnl for t in losses)) if losses and sum(t.pnl for t in losses) != 0 else float("inf")

        return {
            "initial_balance": self.initial_balance,
            "current_balance": round(self.balance, 2),
            "total_return_percent": round((self.balance - self.initial_balance) / self.initial_balance * 100, 2),
            "total_pnl": round(total_pnl, 2),
            "total_fees": round(total_fees, 2),
            "total_trades": total,
            "winning_trades": len(wins),
            "losing_trades": len(losses),
            "win_rate": round(win_rate, 2),
            "avg_win": round(avg_win, 2),
            "avg_loss": round(avg_loss, 2),
            "profit_factor": round(profit_factor, 2),
            "open_positions": len(self._positions),
            "risk_status": self.risk_engine.get_risk_summary("paper_user"),
        }

    def get_open_positions(self) -> List[Dict]:
        return [
            {
                "id": p.id, "symbol": p.symbol, "direction": p.direction,
                "entry_price": p.entry_price, "current_price": p.current_price,
                "quantity": p.quantity, "unrealized_pnl": round(p.unrealized_pnl, 2),
                "unrealized_pnl_percent": round(p.unrealized_pnl_percent, 2),
                "stop_loss": p.stop_loss, "take_profit_1": p.take_profit_1,
                "opened_at": p.opened_at,
            }
            for p in self._positions.values()
        ]
