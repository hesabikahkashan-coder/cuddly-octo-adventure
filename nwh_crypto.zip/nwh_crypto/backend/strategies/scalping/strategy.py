"""
Scalping Strategy
High-frequency short-term trades on 1m/5m timeframes.
Uses RSI, Bollinger Bands, and volume spikes.
"""
from typing import List, Dict, Optional
from dataclasses import dataclass
from ..base_strategy import BaseStrategy, StrategySignal, SignalType, StrategyConfig
from ..technical_indicators import TechnicalIndicators
from ...core.logging import get_logger

logger = get_logger(__name__)


@dataclass
class ScalpingConfig(StrategyConfig):
    rsi_period: int = 7
    rsi_oversold: float = 25.0
    rsi_overbought: float = 75.0
    bb_period: int = 20
    bb_std: float = 2.0
    min_volume_ratio: float = 1.5  # Volume must be 1.5x average
    take_profit_atr_mult: float = 1.5
    stop_loss_atr_mult: float = 0.75


class ScalpingStrategy(BaseStrategy):
    """
    Scalping Strategy for 1m/5m timeframes.
    
    Entry: RSI extreme + BB bounce + Volume spike
    Exit: Quick TP (1.5x ATR) or SL (0.75x ATR)
    """

    def __init__(self, config: Optional[ScalpingConfig] = None):
        if config is None:
            config = ScalpingConfig(
                name="Scalping",
                symbols=["BTC/USDT", "ETH/USDT"],
                timeframe="5m",
                risk_per_trade_percent=0.5  # Lower risk per trade for scalping
            )
        super().__init__(config)
        self.sc_config: ScalpingConfig = config

    def get_required_candles(self) -> int:
        return 50

    async def analyze(self, symbol: str, candles: List[Dict]) -> StrategySignal:
        try:
            df = TechnicalIndicators.to_dataframe(candles)
            current_price = df["close"].iloc[-1]

            rsi = TechnicalIndicators.rsi(df, self.sc_config.rsi_period)
            bb = TechnicalIndicators.bollinger_bands(df, self.sc_config.bb_period, self.sc_config.bb_std)
            atr = TechnicalIndicators.atr(df)
            volume = TechnicalIndicators.volume_analysis(df)

            indicators = {
                "rsi": rsi.value, "bb_upper": bb.upper, "bb_lower": bb.lower,
                "bb_middle": bb.middle, "atr": atr, "volume_ratio": volume["volume_ratio"]
            }

            has_volume = volume["volume_ratio"] >= self.sc_config.min_volume_ratio

            # LONG: RSI oversold + price at/below lower BB + volume
            if rsi.is_oversold and bb.price_position == "below_lower" and has_volume:
                sl = current_price - (atr * self.sc_config.stop_loss_atr_mult)
                tp = current_price + (atr * self.sc_config.take_profit_atr_mult)
                return StrategySignal(
                    signal_type=SignalType.BUY, symbol=symbol,
                    timeframe=self.config.timeframe, confidence=0.75,
                    entry_price=current_price, stop_loss=round(sl, 6),
                    take_profit_1=round(tp, 6),
                    reason=f"Scalp long: RSI={rsi.value:.1f} + BB lower touch + volume spike",
                    indicators=indicators
                )

            # SHORT: RSI overbought + price at/above upper BB + volume
            if rsi.is_overbought and bb.price_position == "above_upper" and has_volume:
                sl = current_price + (atr * self.sc_config.stop_loss_atr_mult)
                tp = current_price - (atr * self.sc_config.take_profit_atr_mult)
                return StrategySignal(
                    signal_type=SignalType.SELL, symbol=symbol,
                    timeframe=self.config.timeframe, confidence=0.75,
                    entry_price=current_price, stop_loss=round(sl, 6),
                    take_profit_1=round(tp, 6),
                    reason=f"Scalp short: RSI={rsi.value:.1f} + BB upper touch + volume spike",
                    indicators=indicators
                )

            return StrategySignal(
                signal_type=SignalType.HOLD, symbol=symbol,
                timeframe=self.config.timeframe, confidence=0.0,
                reason="No scalp signal", indicators=indicators
            )

        except Exception as e:
            logger.error(f"Scalping analysis error: {e}")
            return StrategySignal(signal_type=SignalType.HOLD, symbol=symbol,
                                  timeframe=self.config.timeframe, confidence=0.0, reason=str(e))
